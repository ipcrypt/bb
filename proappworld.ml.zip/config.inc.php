<?php
define("HOSTNAME_MTA_PUBLISH", "sdbemta04.simdif.local");
define("EMAIL_CONFIRMED", true);
define("SITE_URL", "http://www.proappworld.ml");
define("SENDER_EMAIL", "contact@simdif.com");
define("SENDER_NAME", "contact");
define("RECEIVER_EMAIL", "ipromiseimoniye@gmail.com");
define("RECEIVER_NAME", "Promise");
define("RECEIVER_LASTNAME", "Imoniye");
define("SUBJECT", "[sender_email] via [site_name]: [form_subject]");
define("CONTENT", "You have a message from &lt;[sender_email]&gt;, via your contact page on [site_name]");
define("USER_ID", "32435");
define("SITE_ID", "645855");
define("ENV", "prod");
