var map_blocks = {};

$(document).ready( function() {
    for( var i in map_blocks )
    {
        showMap(i);
    }
});
    
/* show user's map in block */
function showMap(block_id)
{
    var block   = map_blocks[block_id];
    var myzoom  = parseInt(block.bct_map_zoom) || 14;
    
    // load coordinate from db
    var myMapPoint = strToFloat(block.bct_map_coordinate);
    
    //if coordinate is not correct then use default
    if( isNaN(myMapPoint.lat()) || isNaN(myMapPoint.lng()) )
        myMapPoint = new google.maps.LatLng(18.788688, 98.987889);
    
    var mapOptions = {
        zoom        : myzoom,
        center      : myMapPoint,
        streetViewControl: false,
        mapTypeId   : google.maps.MapTypeId.ROADMAP
    }
    
    var myMap = new google.maps.Map($('[sd-data-block-id='+block_id+'] .sd-block-map-content')[0], mapOptions);
    
    if( myMapPoint )
    {
        var info = block.bct_map_info || '';
        var myMarker = new google.maps.Marker({
                position    : myMapPoint,
                map         : myMap,
                clickable   : false
        	});
        
        /*
        if( info != "" )
        {
            google.maps.event.addListener(myMarker, 'click', function(){
    			var infowindow = new google.maps.InfoWindow({
    				content : '<div style="font-size:small"><textarea readonly="value" style="border:0px; rows="5" cols="30">'+decodeURIComponent(info)+'</textarea></div>'
    			});
    			
    			infowindow.open(myMap, myMarker);
    		});
    	}
    	*/
    }

}

/* convert latitude , longtitude to float */
function strToFloat(str)
{
	var str         = str.substr(1,str.length-2);
	var pointArray  = str.split(',');
	var lat         =  parseFloat(pointArray[0]);
	var lng         =  parseFloat(pointArray[1]);
	var myPointObj  = new google.maps.LatLng(lat, lng);
	
	return myPointObj;
}